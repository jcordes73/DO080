'use strict';


var EventEmitter = require("events").EventEmitter
 ,  thousandEmitter = new EventEmitter();

 module.exports = thousandEmitter;
