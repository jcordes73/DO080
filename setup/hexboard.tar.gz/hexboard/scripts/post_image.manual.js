'use strict';

var sketch = require('../server/hexboard/sketch')
  ;

sketch.postRandomImage('localhost:9000');
// sketch.postRandomImage('keynote2015-hexboard.demo.router.default.local:1080');
// sketch.postRandomImage('ui.hexboard.apps.aws.paas.ninja');
